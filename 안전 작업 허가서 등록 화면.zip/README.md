
  # 안전 작업 허가서 등록 화면

  This is a code bundle for 안전 작업 허가서 등록 화면. The original project is available at https://www.figma.com/design/0gQTL5pcJxC4C4w7JJT2nN/%EC%95%88%EC%A0%84-%EC%9E%91%EC%97%85-%ED%97%88%EA%B0%80%EC%84%9C-%EB%93%B1%EB%A1%9D-%ED%99%94%EB%A9%B4.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  