import { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
}

export function Card({ children, className = '' }: CardProps) {
  return (
    <div className={`bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden ${className}`}>
      {children}
    </div>
  );
}

interface CardSectionProps {
  children: ReactNode;
  className?: string;
  noBorder?: boolean;
}

export function CardSection({ children, className = '', noBorder = false }: CardSectionProps) {
  return (
    <div className={`p-4 md:p-6 ${!noBorder ? 'border-b border-gray-200' : ''} ${className}`}>
      {children}
    </div>
  );
}

interface SectionHeaderProps {
  title: string;
  badge?: string;
  action?: ReactNode;
}

export function SectionHeader({ title, badge, action }: SectionHeaderProps) {
  return (
    <div className="flex items-center justify-between mb-6">
      <div className="flex items-center gap-2">
        <div className="w-1 h-6 bg-gradient-to-b from-[#FF6B35] to-[#F7931E] rounded-full"></div>
        <h2 className="text-gray-900">{title}</h2>
        {badge && (
          <span className="text-xs text-[#FF6B35] bg-orange-50 px-2 py-1 rounded">
            {badge}
          </span>
        )}
      </div>
      {action && <div>{action}</div>}
    </div>
  );
}
