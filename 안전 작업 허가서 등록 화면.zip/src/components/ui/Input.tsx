import { InputHTMLAttributes, forwardRef } from 'react';
import { LucideIcon } from 'lucide-react';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  icon?: LucideIcon;
  required?: boolean;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, icon: Icon, required, className = '', ...props }, ref) => {
    return (
      <div className="w-full">
        {label && (
          <label className="block text-sm text-gray-700 mb-2 font-medium">
            {label} {required && <span className="text-[#FF6B35]">*</span>}
          </label>
        )}
        <div className="relative">
          <input
            ref={ref}
            className={`w-full px-4 py-2.5 border rounded-lg text-sm transition-all focus:outline-none focus:ring-2 focus:ring-[#FF6B35]/20 ${
              error 
                ? 'border-red-500 focus:border-red-500' 
                : 'border-gray-300 focus:border-[#FF6B35]'
            } ${Icon ? 'pr-10' : ''} ${className}`}
            {...props}
          />
          {Icon && (
            <Icon className="absolute right-3 top-3 w-4 h-4 text-gray-400 pointer-events-none" />
          )}
        </div>
        {error && (
          <p className="mt-1 text-xs text-red-600">{error}</p>
        )}
      </div>
    );
  }
);

Input.displayName = 'Input';
